// This is a bridge file to maintain compatibility with the existing workflow
// It just imports and runs our main server.js file

import '../server.js';